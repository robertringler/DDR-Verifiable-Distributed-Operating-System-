# DDR Verifiable Distributed OS

A deterministic, verifiable distributed operating system architecture with:
- Governance layer
- Consensus layer
- Execution kernel
- Network layer
- Bootstrap layer
- Formal refinement mapping between TLA+ and Rust

## Build

```bash
cargo build
cargo run
```

## Repository Structure

- `crates/governance` — validator and epoch management
- `crates/consensus` — quorum certificate logic
- `crates/execution` — deterministic state machine
- `crates/network` — attested gossip substrate
- `crates/bootstrap` — genesis proof system
- `specs/` — TLA+ formal models
