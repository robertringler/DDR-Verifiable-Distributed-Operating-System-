use sha2::{Digest, Sha256};

pub struct QuorumCertificate {
    pub hash: String,
}

impl QuorumCertificate {
    pub fn genesis() -> Self {
        let mut hasher = Sha256::new();
        hasher.update(b"genesis-qc");
        let result = hasher.finalize();

        Self {
            hash: hex::encode(result),
        }
    }
}
