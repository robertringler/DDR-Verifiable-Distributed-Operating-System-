use sha2::{Digest, Sha256};

pub struct ExecutionKernel {
    log: Vec<String>,
}

impl ExecutionKernel {
    pub fn new() -> Self {
        Self {
            log: vec!["GENESIS".into()],
        }
    }

    pub fn reduce(&self) -> String {
        let mut hasher = Sha256::new();

        for entry in &self.log {
            hasher.update(entry.as_bytes());
        }

        hex::encode(hasher.finalize())
    }

    pub fn state_root(&self) -> String {
        self.reduce()
    }
}
