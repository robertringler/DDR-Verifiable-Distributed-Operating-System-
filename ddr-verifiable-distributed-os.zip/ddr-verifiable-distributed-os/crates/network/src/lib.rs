pub struct NetworkNode {
    pub node_id: String,
}

impl NetworkNode {
    pub fn new(id: &str) -> Self {
        Self {
            node_id: id.to_string(),
        }
    }

    pub fn propagate_qc(&self) {
        println!("QC-first propagation from {}", self.node_id);
    }
}
