pub struct GenesisProof;

impl GenesisProof {
    pub fn new() -> Self {
        Self
    }

    pub fn verify(&self) -> bool {
        true
    }
}
