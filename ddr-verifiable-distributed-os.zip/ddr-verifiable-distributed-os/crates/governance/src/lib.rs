use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GovernanceState {
    pub epoch: u64,
    pub validator_set: Vec<String>,
}

impl Default for GovernanceState {
    fn default() -> Self {
        Self {
            epoch: 0,
            validator_set: vec![
                "validator-a".into(),
                "validator-b".into(),
                "validator-c".into(),
            ],
        }
    }
}
