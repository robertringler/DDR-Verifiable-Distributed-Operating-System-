use bootstrap::GenesisProof;
use consensus::QuorumCertificate;
use execution::ExecutionKernel;
use governance::GovernanceState;
use network::NetworkNode;

#[tokio::main]
async fn main() {
    println!("DDR Verifiable Distributed OS");

    let governance = GovernanceState::default();
    let qc = QuorumCertificate::genesis();
    let kernel = ExecutionKernel::new();
    let network = NetworkNode::new("node-0");
    let genesis = GenesisProof::new();

    println!("Governance epoch: {}", governance.epoch);
    println!("Genesis QC hash: {}", qc.hash);
    println!("Execution root: {}", kernel.state_root());
    println!("Network node: {}", network.node_id);
    println!("Genesis proof valid: {}", genesis.verify());
}
