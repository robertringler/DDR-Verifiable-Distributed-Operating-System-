----------------------------- MODULE DDRSystem -----------------------------
EXTENDS Naturals, Sequences

VARIABLES state, validators, epoch

Init ==
    /\ state = "GENESIS"
    /\ epoch = 0
    /\ validators = << "A", "B", "C" >>

Next ==
    /\ state' = state
    /\ epoch' = epoch + 1
    /\ validators' = validators

Spec == Init /\ [][Next]_<<state, validators, epoch>>

=============================================================================
